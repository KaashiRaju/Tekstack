//DO NOT CHANGE THE CODE SKELETON
import React,{Component} from 'react';
import { BrowserRouter as Router,Route,Routes,Link} from 'react-router-dom';
import DisplayProducts from './Components/DisplayProducts.js';
import ViewCart from './Components/ViewCart.js';
const styles={
 
    nav:{borderBottom: "groove 0.5em",borderTop: "groove 0.5em",paddingBottom: "1rem", fontWeight:"bolder",backgroundColor:"#B3C7D6FF"},
     h1:{textAlign:"center", color:"#ffffff", backgroundColor:"#293241",minHeight:"2em",paddingTop:"0.5em"}
 
   // Fill the remaining styles
   
}

class App extends Component {

   // Write your code here and apply the corresponding styles to the respective elements
  
    render(){
            return(null);
    }
}


export default App;