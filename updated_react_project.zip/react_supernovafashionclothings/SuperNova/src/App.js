import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import DisplayProducts from "./DisplayProducts";
import ViewCart from "./ViewCart";

function App() {
  return (
    <Router>
      <div
        style={{
          background: "linear-gradient(to right, #0052b0, #520f41)",
          minHeight: "950px",
          color: "white",
          padding: "20px",
        }}
      >
        <h1>Super Nova Fashion Clothings</h1>

        <nav style={{ marginBottom: "20px" }}>
          <Link to="/displayProducts" style={{ marginRight: "20px", fontSize: "1.3em", color: "white" }}>
            Display Products
          </Link>

          <Link to="/viewCart" style={{ fontSize: "1.3em", color: "white" }}>
            View Cart
          </Link>
        </nav>

        <Routes>
          <Route path="/displayProducts" element={<DisplayProducts />} />
          <Route path="/viewCart" element={<ViewCart />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
