// DO NOT CHANGE THE IMPORT STATEMENTS
import React, { Component } from "react";
import ReactDOM from 'react-dom';
import productList from "../products.json";
import { useState } from "react";
import { Route,Routes,Link, Router, BrowserRouter} from 'react-router-dom';
import ViewCart from "./ViewCart";
import Service from "../Service/Service.js";

const styles={
    div: {
      marginLeft:"100px",
      backgroundColor:"#00563B",
      maxHeight:"8em", 
      width:"27%",
      color:"#DADD98"
    }
    
    // Fill the remaining styles
    
}
class DisplayProducts extends Component{
    
    cartHandler=(index)=> {
        
        // Invoke addToCart function which is present inside Service.js file
        
     }

    render(){    
    return(
        
		<div>
          
            {/*// Implement your code here to read and display all the products from 'products.json' file */} 
          
          <p>**Products cannot be returned nor exchanged once purchased.</p>
        </div>
    )
 }
}
export default DisplayProducts