// DO NOT CHANGE THE IMPORT STATEMENTS
import React from 'react';   
import Service from "../Service/Service.js";

function ViewCart(){
    const styles={
    	div:{
    	    marginLeft:"100px",
    	    minHeight:"5em",
    	    width:"30%",
    	    color:"#ffffff"
    	}
	
    
    // Fill the remaining styles
    
}
    
    // Retrieve cartList from Service.js file using 'viewCart' function
   
   // Remove 'null' and Implement your code inside return to display the selected product(s) from cartList as described
	
	return(null);	
}
export default ViewCart;