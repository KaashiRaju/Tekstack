import React from "react";
import products from "./products.json";
import { addToCart } from "./Service";

function DisplayProducts() {
  const cartHandler = (index) => {
    addToCart(index);
  };

  return (
    <div>
      <dl>
        {products.map((product, index) => (
          <div key={index}>
            <dt style={{ fontWeight: "bold", backgroundColor: "#ddd" }}>
              {product.title}
            </dt>

            <dd>Product Id: {product.id}</dd>
            <dd>Price: {product.price}</dd>

            <dd>
              Available Sizes:
              <table border="1">
                <tbody>
                  <tr>
                    {product.availableSizes.map((size, i) => (
                      <td key={i}>{size}</td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </dd>

            <dd>
              <button style={{ float: "right" }} onClick={cartHandler.bind(this, index)}>
                Add To Cart
              </button>
            </dd>
          </div>
        ))}
      </dl>

      <p>*Products cannot be returned nor exchanged once purchased.</p>
    </div>
  );
}

export default DisplayProducts;
