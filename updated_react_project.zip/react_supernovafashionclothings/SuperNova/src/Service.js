import products from "./products.json";

let cartList = [];

export const addToCart = (index) => {
  cartList.push(products[index]);
  alert("Product added to cart");
};

export const viewCart = () => {
  return cartList;
};
