import React from "react";
import { viewCart } from "./Service";

function ViewCart() {
  const cart = viewCart();

  return (
    <div>
      {cart.length === 0 ? (
        <p>There are no items in the Cart list that can be shown.</p>
      ) : (
        <dl>
          {cart.map((item, index) => (
            <div key={index}>
              <dt>{item.title}</dt>
              <dd>Product Id: {item.id}</dd>
              <dd>Price: {item.price}</dd>
            </div>
          ))}
        </dl>
      )}
    </div>
  );
}

export default ViewCart;
